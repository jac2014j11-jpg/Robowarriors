import { Check, Minus, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

type StatusType = "active" | "inactive" | "error";

interface StatusIndicatorProps {
  status: StatusType;
  label?: string;
  size?: "sm" | "md" | "lg";
}

const statusConfig = {
  active: {
    icon: Check,
    className: "text-green-500",
    bgClass: "bg-green-500/20",
    label: "Active",
  },
  inactive: {
    icon: Minus,
    className: "text-muted-foreground",
    bgClass: "bg-muted",
    label: "Inactive",
  },
  error: {
    icon: AlertTriangle,
    className: "text-red-500",
    bgClass: "bg-red-500/20",
    label: "Error",
  },
};

const sizeConfig = {
  sm: { icon: "h-3 w-3", dot: "h-2 w-2", text: "text-xs" },
  md: { icon: "h-4 w-4", dot: "h-3 w-3", text: "text-sm" },
  lg: { icon: "h-5 w-5", dot: "h-4 w-4", text: "text-base" },
};

export function StatusIndicator({
  status,
  label,
  size = "md",
}: StatusIndicatorProps) {
  const config = statusConfig[status];
  const sizes = sizeConfig[size];
  const Icon = config.icon;

  return (
    <div className="flex items-center gap-2">
      <div
        className={cn(
          "flex items-center justify-center rounded-full",
          config.bgClass,
          sizes.dot === "h-2 w-2" ? "p-1" : sizes.dot === "h-3 w-3" ? "p-1.5" : "p-2"
        )}
      >
        <Icon className={cn(sizes.icon, config.className)} />
      </div>
      {label && (
        <span className={cn(sizes.text, "text-foreground")}>{label}</span>
      )}
    </div>
  );
}

export function StatusDot({ status, pulse = false }: { status: StatusType; pulse?: boolean }) {
  const colorClass = {
    active: "bg-green-500",
    inactive: "bg-muted-foreground",
    error: "bg-red-500",
  }[status];

  return (
    <div
      className={cn(
        "h-3 w-3 rounded-full",
        colorClass,
        pulse && status === "active" && "animate-pulse"
      )}
    />
  );
}
