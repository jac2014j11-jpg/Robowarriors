import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { StatusDot } from "./status-indicator";
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Square,
  Sun,
  Radio,
  Satellite,
  Lock,
  Unlock,
  Scan,
} from "lucide-react";
import type { RoverStatus, RoverCommand } from "@shared/schema";

interface RoverControlsProps {
  status: RoverStatus | undefined;
  onCommand: (command: RoverCommand) => void;
  isLoading?: boolean;
}

export function RoverControls({ status, onCommand, isLoading }: RoverControlsProps) {
  const [speed, setSpeed] = useState(status?.speed || 50);

  const handleMove = (direction: 'forward' | 'backward' | 'left' | 'right') => {
    onCommand({ type: 'move', direction });
  };

  const handleStop = () => {
    onCommand({ type: 'stop' });
  };

  const handleToggle = (type: 'toggle_solar' | 'toggle_lora' | 'toggle_starlink' | 'toggle_manual' | 'toggle_gpr', currentValue: boolean) => {
    onCommand({ type, value: !currentValue });
  };

  const handleSpeedChange = (value: number[]) => {
    const newSpeed = value[0];
    setSpeed(newSpeed);
    onCommand({ type: 'set_speed', value: newSpeed });
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center justify-between gap-2 text-lg font-medium">
          <span>Rover Controls</span>
          <div className="flex items-center gap-2">
            <StatusDot status={status?.manualOverride ? "active" : "inactive"} pulse={status?.manualOverride} />
            <span className="text-xs font-normal text-muted-foreground">
              {status?.manualOverride ? "Manual" : "Auto"}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-yellow-500/20">
                <Sun className="h-4 w-4 text-yellow-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">Solar Panel</Label>
                <p className="text-xs text-muted-foreground">Power management</p>
              </div>
            </div>
            <Switch
              checked={status?.solarPanelActive || false}
              onCheckedChange={() => handleToggle('toggle_solar', status?.solarPanelActive || false)}
              disabled={isLoading}
              data-testid="switch-solar-panel"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-500/20">
                <Radio className="h-4 w-4 text-blue-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">LoRa WAN</Label>
                <p className="text-xs text-muted-foreground">Local communication</p>
              </div>
            </div>
            <Switch
              checked={status?.loraWanActive || false}
              onCheckedChange={() => handleToggle('toggle_lora', status?.loraWanActive || false)}
              disabled={isLoading}
              data-testid="switch-lora-wan"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-purple-500/20">
                <Satellite className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">Starlink</Label>
                <p className="text-xs text-muted-foreground">Satellite network</p>
              </div>
            </div>
            <Switch
              checked={status?.starlinkConnected || false}
              onCheckedChange={() => handleToggle('toggle_starlink', status?.starlinkConnected || false)}
              disabled={isLoading}
              data-testid="switch-starlink"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-green-500/20">
                <Scan className="h-4 w-4 text-green-500" />
              </div>
              <div>
                <Label className="text-sm font-medium">GPR Scanner</Label>
                <p className="text-xs text-muted-foreground">Ground radar</p>
              </div>
            </div>
            <Switch
              checked={status?.gprActive || false}
              onCheckedChange={() => handleToggle('toggle_gpr', status?.gprActive || false)}
              disabled={isLoading}
              data-testid="switch-gpr"
            />
          </div>
        </div>

        <div className="border-t border-border pt-4">
          <Label className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
            Movement Control
          </Label>
          <div className="mt-4 flex flex-col items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              className="h-12 w-12"
              onClick={() => handleMove('forward')}
              disabled={!status?.manualOverride || isLoading}
              data-testid="button-move-forward"
            >
              <ChevronUp className="h-6 w-6" />
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-12 w-12"
                onClick={() => handleMove('left')}
                disabled={!status?.manualOverride || isLoading}
                data-testid="button-move-left"
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <Button
                variant="destructive"
                size="icon"
                className="h-12 w-12"
                onClick={handleStop}
                disabled={!status?.manualOverride || isLoading}
                data-testid="button-stop"
              >
                <Square className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="h-12 w-12"
                onClick={() => handleMove('right')}
                disabled={!status?.manualOverride || isLoading}
                data-testid="button-move-right"
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </div>
            <Button
              variant="outline"
              size="icon"
              className="h-12 w-12"
              onClick={() => handleMove('backward')}
              disabled={!status?.manualOverride || isLoading}
              data-testid="button-move-backward"
            >
              <ChevronDown className="h-6 w-6" />
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Speed</Label>
            <span className="font-mono text-sm text-muted-foreground">{speed}%</span>
          </div>
          <Slider
            value={[speed]}
            onValueChange={handleSpeedChange}
            max={100}
            min={0}
            step={5}
            disabled={!status?.manualOverride || isLoading}
            data-testid="slider-speed"
          />
        </div>

        <div className="border-t border-border pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-orange-500/20">
                {status?.manualOverride ? (
                  <Unlock className="h-4 w-4 text-orange-500" />
                ) : (
                  <Lock className="h-4 w-4 text-orange-500" />
                )}
              </div>
              <div>
                <Label className="text-sm font-medium">Manual Override</Label>
                <p className="text-xs text-muted-foreground">Direct control</p>
              </div>
            </div>
            <Switch
              checked={status?.manualOverride || false}
              onCheckedChange={() => handleToggle('toggle_manual', status?.manualOverride || false)}
              disabled={isLoading}
              data-testid="switch-manual-override"
            />
          </div>
        </div>

        <Button
          variant="destructive"
          className="h-14 w-full text-lg font-semibold"
          onClick={handleStop}
          disabled={isLoading}
          data-testid="button-emergency-stop"
        >
          EMERGENCY STOP
        </Button>
      </CardContent>
    </Card>
  );
}
