import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { RoverControls } from "@/components/rover-controls";
import { StatusDashboard } from "@/components/status-dashboard";
import { GPSDisplay } from "@/components/gps-display";
import { GPRViewer } from "@/components/gpr-viewer";
import { ScanResultsTable } from "@/components/scan-results-table";
import { useToast } from "@/hooks/use-toast";
import type { RoverStatus, RoverCommand, GPRScan } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: roverStatus, isLoading: isLoadingStatus } = useQuery<RoverStatus>({
    queryKey: ["/api/rover/status"],
    refetchInterval: 2000,
  });

  const { data: scans = [], isLoading: isLoadingScans } = useQuery<GPRScan[]>({
    queryKey: ["/api/scans"],
  });

  const { data: currentScan } = useQuery<GPRScan>({
    queryKey: ["/api/scans/current"],
    refetchInterval: roverStatus?.activeScans ? 1000 : false,
    retry: false,
  });

  const commandMutation = useMutation({
    mutationFn: async (command: RoverCommand) => {
      return apiRequest("POST", "/api/rover/command", command);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rover/status"] });
    },
    onError: (error) => {
      toast({
        title: "Command Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const startScanMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scans/start", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rover/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      toast({
        title: "Scan Started",
        description: "GPR scanning is now active",
      });
    },
  });

  const stopScanMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scans/stop", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rover/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      toast({
        title: "Scan Stopped",
        description: "GPR scanning has been stopped",
      });
    },
  });

  const handleCommand = (command: RoverCommand) => {
    commandMutation.mutate(command);
  };

  const handleViewScan = (scan: GPRScan) => {
    toast({
      title: "Viewing Scan",
      description: `Loading scan from ${new Date(scan.timestamp).toLocaleString()}`,
    });
  };

  const handleDeleteScan = (id: string) => {
    toast({
      title: "Scan Deleted",
      description: "The scan has been removed",
    });
    queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
  };

  const handleExportScan = (scan: GPRScan) => {
    toast({
      title: "Export Started",
      description: "Preparing scan data for download...",
    });
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold">Mission Control Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Monitor and control your archaeological survey rover
        </p>
      </div>

      <StatusDashboard status={roverStatus} isLoading={isLoadingStatus} />

      <GPSDisplay status={roverStatus} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <GPRViewer
            scan={currentScan}
            isScanning={Boolean(roverStatus?.activeScans)}
            onStartScan={() => startScanMutation.mutate()}
            onStopScan={() => stopScanMutation.mutate()}
          />
        </div>
        <div>
          <RoverControls
            status={roverStatus}
            onCommand={handleCommand}
            isLoading={commandMutation.isPending}
          />
        </div>
      </div>

      <ScanResultsTable
        scans={scans}
        onViewScan={handleViewScan}
        onDeleteScan={handleDeleteScan}
        onExportScan={handleExportScan}
        isLoading={isLoadingScans}
      />
    </div>
  );
}
