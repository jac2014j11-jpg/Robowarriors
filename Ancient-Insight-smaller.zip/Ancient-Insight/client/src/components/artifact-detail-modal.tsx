import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ExternalLink, MapPin, Calendar, Ruler, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Artifact } from "@shared/schema";

interface ArtifactDetailModalProps {
  artifact: Artifact | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ArtifactDetailModal({
  artifact,
  open,
  onOpenChange,
}: ArtifactDetailModalProps) {
  const { toast } = useToast();

  if (!artifact) return null;

  const copyCoordinates = () => {
    const coords = `${artifact.gpsLat.toFixed(6)}, ${artifact.gpsLng.toFixed(6)}`;
    navigator.clipboard.writeText(coords);
    toast({
      title: "Coordinates Copied",
      description: coords,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl" data-testid="modal-artifact-detail">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            {artifact.name}
            {artifact.similarity >= 0.8 && (
              <Badge className="bg-green-500/20 text-green-600 dark:text-green-400">
                {(artifact.similarity * 100).toFixed(0)}% Match
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription className="sr-only">
            Detailed information about the artifact including description, location, and GPS coordinates
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="aspect-4/3 overflow-hidden rounded-lg bg-muted">
            {artifact.imageUrl ? (
              <img
                src={artifact.imageUrl}
                alt={artifact.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
                <MapPin className="h-24 w-24 text-muted-foreground/30" />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="mb-2 text-sm font-medium uppercase tracking-wide text-muted-foreground">
                Description
              </h4>
              <p className="text-sm leading-relaxed">{artifact.description}</p>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Category
                </h4>
                <Badge variant="secondary">{artifact.category}</Badge>
              </div>
              <div>
                <h4 className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Period
                </h4>
                <Badge variant="outline">{artifact.period}</Badge>
              </div>
            </div>

            <Separator />

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{artifact.location}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Found: {new Date(artifact.dateFound).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <Ruler className="h-4 w-4 text-muted-foreground" />
                  <span>Depth: {artifact.depth.toFixed(2)}m</span>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                GPS Coordinates
              </h4>
              <div className="flex items-center gap-2">
                <code className="flex-1 rounded-md bg-muted px-3 py-2 font-mono text-sm">
                  {artifact.gpsLat.toFixed(6)}, {artifact.gpsLng.toFixed(6)}
                </code>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={copyCoordinates}
                  data-testid="button-copy-artifact-coordinates"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {artifact.externalLink && (
          <div className="mt-4 flex justify-end">
            <Button asChild data-testid="button-artifact-external-link">
              <a href={artifact.externalLink} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-2 h-4 w-4" />
                View Full Record
              </a>
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
