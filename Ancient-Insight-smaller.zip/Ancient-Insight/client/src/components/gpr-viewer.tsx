import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Scan,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Play,
  Pause,
  Maximize2,
} from "lucide-react";
import type { GPRScan } from "@shared/schema";

interface GPRViewerProps {
  scan: GPRScan | undefined;
  isScanning?: boolean;
  onStartScan?: () => void;
  onStopScan?: () => void;
}

export function GPRViewer({ scan, isScanning, onStartScan, onStopScan }: GPRViewerProps) {
  const [viewMode, setViewMode] = useState<"2d" | "3d">("2d");
  const [depth, setDepth] = useState([50]);
  const [zoom, setZoom] = useState(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const scanLineRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const drawRadarProfile = () => {
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(0, 0, width, height);

      drawLayerBoundaries(ctx, width, height);
      drawHyperbolas(ctx, width, height);
      drawMaterialChanges(ctx, width, height);
      drawScanWaves(ctx, width, height);

      if (isScanning) {
        scanLineRef.current = (scanLineRef.current + 2) % width;
        ctx.strokeStyle = "rgba(59, 130, 246, 0.8)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(scanLineRef.current, 0);
        ctx.lineTo(scanLineRef.current, height);
        ctx.stroke();

        ctx.fillStyle = "rgba(59, 130, 246, 0.15)";
        ctx.fillRect(0, 0, scanLineRef.current, height);
      }

      if (scan?.artifactDetected) {
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 3;
        ctx.strokeRect(width * 0.35, height * 0.45, width * 0.3, height * 0.25);
        
        ctx.fillStyle = "#f59e0b";
        ctx.font = "bold 14px Inter, sans-serif";
        ctx.fillText("ARTIFACT SIGNATURE", width * 0.37, height * 0.42);
      }
    };

    const draw3DView = () => {
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(0, 0, width, height);

      const gridSpacing = 30;
      const perspective = 0.4;
      
      ctx.strokeStyle = "#1e3a5f";
      ctx.lineWidth = 1;
      
      for (let z = 0; z < height * 0.7; z += gridSpacing) {
        const scale = 1 - (z / height) * perspective;
        const offsetX = (width * (1 - scale)) / 2;
        
        ctx.beginPath();
        ctx.moveTo(offsetX, height * 0.2 + z);
        ctx.lineTo(width - offsetX, height * 0.2 + z);
        ctx.stroke();
      }
      
      for (let x = 0; x < width; x += gridSpacing) {
        const startX = x;
        const endX = width / 2 + (x - width / 2) * (1 - perspective);
        ctx.beginPath();
        ctx.moveTo(startX, height * 0.2);
        ctx.lineTo(endX, height * 0.9);
        ctx.stroke();
      }

      if (scan?.artifactDetected) {
        const cx = width * 0.5;
        const cy = height * 0.5;
        const rx = 40;
        const ry = 25;
        
        const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, rx);
        gradient.addColorStop(0, "rgba(245, 158, 11, 0.8)");
        gradient.addColorStop(0.5, "rgba(245, 158, 11, 0.4)");
        gradient.addColorStop(1, "rgba(245, 158, 11, 0.1)");
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    };

    if (viewMode === "3d") {
      draw3DView();
    } else if (scan?.dataPoints && scan.dataPoints.length > 0) {
      const dataPoints = scan.dataPoints;
      const rows = dataPoints.length;
      const cols = dataPoints[0]?.length || 0;

      if (cols > 0) {
        const cellWidth = width / cols;
        const cellHeight = height / rows;

        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < cols; j++) {
            const value = dataPoints[i][j];
            const normalizedValue = Math.min(255, Math.max(0, value));
            
            const hue = 200 - (normalizedValue / 255) * 60;
            const saturation = 70 + (normalizedValue / 255) * 30;
            const lightness = 20 + (normalizedValue / 255) * 40;
            
            ctx.fillStyle = `hsl(${hue}, ${saturation}%, ${lightness}%)`;
            ctx.fillRect(j * cellWidth, i * cellHeight, cellWidth + 1, cellHeight + 1);
          }
        }

        drawHyperbolasOverlay(ctx, width, height);
        drawLayerLines(ctx, width, height);

        if (scan.artifactDetected) {
          ctx.strokeStyle = "#f59e0b";
          ctx.lineWidth = 3;
          ctx.strokeRect(width * 0.3, height * 0.4, width * 0.4, height * 0.3);
          
          ctx.fillStyle = "#f59e0b";
          ctx.font = "bold 14px Inter, sans-serif";
          ctx.fillText("ARTIFACT DETECTED", width * 0.32, height * 0.38);
        }
      }
    } else {
      drawRadarProfile();
    }

    if (isScanning) {
      animationRef.current = requestAnimationFrame(() => {
        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext("2d");
          if (ctx) {
            if (viewMode === "2d" && !scan?.dataPoints) {
              drawRadarProfile();
            }
          }
        }
      });
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [scan, isScanning, viewMode, depth]);

  const drawLayerBoundaries = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const layers = [
      { y: height * 0.15, color: "#3b5998", label: "Surface" },
      { y: height * 0.35, color: "#5a4a3a", label: "Clay Layer" },
      { y: height * 0.55, color: "#4a5568", label: "Compact Soil" },
      { y: height * 0.75, color: "#6b5b4a", label: "Bedrock Interface" },
    ];

    layers.forEach((layer, index) => {
      ctx.strokeStyle = layer.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      for (let x = 0; x < width; x++) {
        const noise = Math.sin(x * 0.02 + index) * 5 + Math.sin(x * 0.05) * 3;
        const y = layer.y + noise;
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      ctx.fillStyle = layer.color;
      ctx.font = "10px Inter, sans-serif";
      ctx.fillText(layer.label, 5, layer.y - 5);
    });
  };

  const drawHyperbolas = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const reflectors = [
      { x: width * 0.25, y: height * 0.45, intensity: 0.8 },
      { x: width * 0.5, y: height * 0.55, intensity: 1.0 },
      { x: width * 0.7, y: height * 0.4, intensity: 0.6 },
    ];

    reflectors.forEach((reflector) => {
      const gradient = ctx.createRadialGradient(
        reflector.x, reflector.y, 0,
        reflector.x, reflector.y, 60
      );
      gradient.addColorStop(0, `rgba(245, 158, 11, ${reflector.intensity})`);
      gradient.addColorStop(0.5, `rgba(245, 158, 11, ${reflector.intensity * 0.5})`);
      gradient.addColorStop(1, "rgba(245, 158, 11, 0)");

      ctx.strokeStyle = `rgba(255, 200, 100, ${reflector.intensity})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      for (let dx = -50; dx <= 50; dx++) {
        const x = reflector.x + dx;
        const hyperY = reflector.y + Math.sqrt(Math.abs(dx)) * 3;
        if (dx === -50) {
          ctx.moveTo(x, hyperY);
        } else {
          ctx.lineTo(x, hyperY);
        }
      }
      ctx.stroke();

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(reflector.x, reflector.y, 8, 0, Math.PI * 2);
      ctx.fill();
    });
  };

  const drawMaterialChanges = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const changes = [
      { x: width * 0.3, startY: height * 0.2, endY: height * 0.8 },
      { x: width * 0.65, startY: height * 0.25, endY: height * 0.7 },
    ];

    changes.forEach((change) => {
      const gradient = ctx.createLinearGradient(change.x - 10, 0, change.x + 10, 0);
      gradient.addColorStop(0, "rgba(100, 150, 200, 0)");
      gradient.addColorStop(0.5, "rgba(100, 150, 200, 0.4)");
      gradient.addColorStop(1, "rgba(100, 150, 200, 0)");

      ctx.fillStyle = gradient;
      ctx.fillRect(change.x - 10, change.startY, 20, change.endY - change.startY);

      ctx.strokeStyle = "rgba(100, 150, 200, 0.6)";
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(change.x, change.startY);
      ctx.lineTo(change.x, change.endY);
      ctx.stroke();
      ctx.setLineDash([]);
    });
  };

  const drawScanWaves = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = "rgba(59, 130, 246, 0.3)";
    ctx.lineWidth = 1;

    for (let y = 20; y < height; y += 30) {
      ctx.beginPath();
      for (let x = 0; x < width; x++) {
        const wave = Math.sin(x * 0.03 + y * 0.02) * 3 + 
                     Math.sin(x * 0.07 - y * 0.01) * 2;
        const yPos = y + wave;
        if (x === 0) {
          ctx.moveTo(x, yPos);
        } else {
          ctx.lineTo(x, yPos);
        }
      }
      ctx.stroke();
    }
  };

  const drawHyperbolasOverlay = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
    ctx.lineWidth = 1;

    const points = [
      { x: width * 0.3, y: height * 0.5 },
      { x: width * 0.6, y: height * 0.6 },
    ];

    points.forEach((point) => {
      ctx.beginPath();
      for (let dx = -40; dx <= 40; dx++) {
        const x = point.x + dx;
        const hyperY = point.y + Math.sqrt(Math.abs(dx)) * 2;
        if (dx === -40) {
          ctx.moveTo(x, hyperY);
        } else {
          ctx.lineTo(x, hyperY);
        }
      }
      ctx.stroke();
    });
  };

  const drawLayerLines = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
    ctx.lineWidth = 1;

    [0.2, 0.4, 0.6, 0.8].forEach((ratio) => {
      ctx.beginPath();
      for (let x = 0; x < width; x++) {
        const noise = Math.sin(x * 0.015) * 4;
        const y = height * ratio + noise;
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    });
  };

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-medium">
          <Scan className="h-5 w-5 text-primary" />
          GPR Data Feed
        </CardTitle>
        <div className="flex items-center gap-2">
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "2d" | "3d")}>
            <TabsList className="h-8">
              <TabsTrigger value="2d" className="text-xs" data-testid="button-view-2d">
                2D
              </TabsTrigger>
              <TabsTrigger value="3d" className="text-xs" data-testid="button-view-3d">
                3D
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative aspect-video min-h-64 overflow-hidden rounded-lg border border-border bg-black">
          <canvas
            ref={canvasRef}
            width={640}
            height={360}
            className="h-full w-full object-cover"
            style={{ transform: `scale(${zoom})` }}
          />
          
          {isScanning && (
            <div className="absolute right-3 top-3 flex items-center gap-2 rounded-md bg-primary/90 px-3 py-1.5 text-xs font-medium text-primary-foreground">
              <div className="h-2 w-2 animate-pulse rounded-full bg-white" />
              SCANNING
            </div>
          )}

          <div className="absolute bottom-3 left-3 rounded-md bg-black/70 px-2 py-1 font-mono text-xs text-white">
            {viewMode === "2d" ? "Radar Profile View" : "Volumetric 3D View"}
          </div>

          <div className="absolute left-3 top-3 flex flex-col gap-1 rounded-md bg-black/60 p-2 text-xs text-white" data-testid="gpr-legend">
            <div className="flex items-center gap-2" data-testid="legend-hyperbola">
              <div className="h-2 w-4 bg-yellow-500/80 rounded" />
              <span>Hyperbola (Point Reflector)</span>
            </div>
            <div className="flex items-center gap-2" data-testid="legend-layer-boundary">
              <div className="h-0.5 w-4 bg-blue-400" />
              <span>Layer Boundary</span>
            </div>
            <div className="flex items-center gap-2" data-testid="legend-material-change">
              <div className="h-3 w-1 bg-blue-300/50" />
              <span>Material Change</span>
            </div>
          </div>

          <div className="absolute right-3 top-1/2 flex -translate-y-1/2 flex-col gap-1">
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8"
              onClick={() => setZoom((z) => Math.min(z + 0.25, 3))}
              data-testid="button-zoom-in"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8"
              onClick={() => setZoom((z) => Math.max(z - 0.25, 0.5))}
              data-testid="button-zoom-out"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8"
              onClick={() => setZoom(1)}
              data-testid="button-zoom-reset"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8"
              data-testid="button-fullscreen"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap items-end gap-6">
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Depth Level
              </Label>
              <span className="font-mono text-sm">{depth[0]}%</span>
            </div>
            <Slider
              value={depth}
              onValueChange={setDepth}
              max={100}
              min={0}
              step={1}
              data-testid="slider-depth"
            />
          </div>

          <div className="flex gap-2">
            {isScanning ? (
              <Button
                variant="destructive"
                onClick={onStopScan}
                data-testid="button-stop-scan"
              >
                <Pause className="mr-2 h-4 w-4" />
                Stop Scan
              </Button>
            ) : (
              <Button
                variant="default"
                onClick={onStartScan}
                data-testid="button-start-scan"
              >
                <Play className="mr-2 h-4 w-4" />
                Start Scan
              </Button>
            )}
          </div>
        </div>

        {scan && (
          <div className="flex flex-wrap gap-4 rounded-lg border border-border bg-muted/50 p-3">
            <div>
              <span className="text-xs text-muted-foreground">Confidence</span>
              <p className="font-mono text-sm font-medium">{(scan.confidenceScore * 100).toFixed(1)}%</p>
            </div>
            <div>
              <span className="text-xs text-muted-foreground">Depth</span>
              <p className="font-mono text-sm font-medium">{scan.depth.toFixed(2)}m</p>
            </div>
            <div>
              <span className="text-xs text-muted-foreground">Timestamp</span>
              <p className="font-mono text-sm font-medium">
                {new Date(scan.timestamp).toLocaleTimeString()}
              </p>
            </div>
            {scan.artifactDetected && (
              <div>
                <span className="text-xs text-muted-foreground">Status</span>
                <p className="text-sm font-medium text-yellow-500">Artifact Detected</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
