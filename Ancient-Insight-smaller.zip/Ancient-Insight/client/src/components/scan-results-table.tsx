import { useState, useRef, useEffect, Fragment } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ChevronDown,
  ChevronRight,
  Download,
  Eye,
  Trash2,
  FileText,
  RotateCcw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { GPRScan } from "@shared/schema";

interface ScanResultsTableProps {
  scans: GPRScan[];
  onViewScan?: (scan: GPRScan) => void;
  onDeleteScan?: (id: string) => void;
  onExportScan?: (scan: GPRScan) => void;
  isLoading?: boolean;
}

function Scan3DViewer({ scan }: { scan: GPRScan }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const rotationRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    const draw = () => {
      const rotation = rotationRef.current;
      
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = "#1e3a5f";
      ctx.lineWidth = 1;
      
      const gridSize = 40;
      const perspective = 0.5;
      
      for (let y = height * 0.3; y < height * 0.9; y += gridSize) {
        const scale = 1 - ((y - height * 0.3) / (height * 0.6)) * perspective;
        const offsetX = (width * (1 - scale)) / 2;
        ctx.beginPath();
        ctx.moveTo(offsetX, y);
        ctx.lineTo(width - offsetX, y);
        ctx.stroke();
      }
      
      for (let x = 0; x <= width; x += gridSize) {
        const startX = x;
        const endX = width / 2 + (x - width / 2) * (1 - perspective);
        ctx.beginPath();
        ctx.moveTo(startX, height * 0.3);
        ctx.lineTo(endX, height * 0.9);
        ctx.stroke();
      }

      const centerX = width / 2;
      const centerY = height * 0.55;
      const urnWidth = 80;
      const urnHeight = 120;
      
      const rotOffset = Math.sin(rotation * 0.02) * 10;

      ctx.fillStyle = "#4a3728";
      ctx.beginPath();
      ctx.ellipse(centerX + rotOffset, centerY + urnHeight * 0.45, urnWidth * 0.4, 15, 0, 0, Math.PI * 2);
      ctx.fill();

      const bodyGradient = ctx.createRadialGradient(
        centerX + rotOffset - 20, centerY, 0,
        centerX + rotOffset, centerY, urnWidth
      );
      bodyGradient.addColorStop(0, "#8b6914");
      bodyGradient.addColorStop(0.3, "#6b5714");
      bodyGradient.addColorStop(0.7, "#4a3a0a");
      bodyGradient.addColorStop(1, "#2a1a00");
      
      ctx.fillStyle = bodyGradient;
      ctx.beginPath();
      ctx.moveTo(centerX + rotOffset - urnWidth * 0.2, centerY - urnHeight * 0.45);
      ctx.quadraticCurveTo(
        centerX + rotOffset - urnWidth * 0.1, centerY - urnHeight * 0.35,
        centerX + rotOffset - urnWidth * 0.15, centerY - urnHeight * 0.2
      );
      ctx.quadraticCurveTo(
        centerX + rotOffset - urnWidth * 0.5, centerY,
        centerX + rotOffset - urnWidth * 0.4, centerY + urnHeight * 0.3
      );
      ctx.quadraticCurveTo(
        centerX + rotOffset - urnWidth * 0.35, centerY + urnHeight * 0.45,
        centerX + rotOffset, centerY + urnHeight * 0.5
      );
      ctx.quadraticCurveTo(
        centerX + rotOffset + urnWidth * 0.35, centerY + urnHeight * 0.45,
        centerX + rotOffset + urnWidth * 0.4, centerY + urnHeight * 0.3
      );
      ctx.quadraticCurveTo(
        centerX + rotOffset + urnWidth * 0.5, centerY,
        centerX + rotOffset + urnWidth * 0.15, centerY - urnHeight * 0.2
      );
      ctx.quadraticCurveTo(
        centerX + rotOffset + urnWidth * 0.1, centerY - urnHeight * 0.35,
        centerX + rotOffset + urnWidth * 0.2, centerY - urnHeight * 0.45
      );
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "#5a4718";
      ctx.beginPath();
      ctx.ellipse(centerX + rotOffset, centerY - urnHeight * 0.45, urnWidth * 0.2, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = "#3a2708";
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
        const y = centerY - urnHeight * 0.1 + i * 15;
        const xOffset = 5 + i * 3;
        ctx.beginPath();
        ctx.moveTo(centerX + rotOffset - urnWidth * 0.35 + xOffset, y);
        ctx.lineTo(centerX + rotOffset + urnWidth * 0.35 - xOffset, y);
        ctx.stroke();
      }

      ctx.strokeStyle = "rgba(59, 130, 246, 0.5)";
      ctx.lineWidth = 1;
      for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
        const scanX = centerX + Math.cos(angle + rotation * 0.01) * (urnWidth + 30);
        const scanY = centerY + Math.sin(angle + rotation * 0.01) * 40;
        ctx.beginPath();
        ctx.moveTo(scanX, scanY - 50);
        ctx.lineTo(scanX, scanY + 50);
        ctx.stroke();
      }

      ctx.fillStyle = "#f59e0b";
      ctx.font = "bold 12px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("WOODEN URN - 3D RECONSTRUCTION", centerX, height * 0.15);
      
      ctx.font = "10px Inter, sans-serif";
      ctx.fillStyle = "#6b7280";
      ctx.fillText(`Depth: ${scan.depth.toFixed(2)}m | Confidence: ${(scan.confidenceScore * 100).toFixed(0)}%`, centerX, height * 0.2);

      ctx.fillStyle = "rgba(59, 130, 246, 0.2)";
      ctx.beginPath();
      ctx.arc(centerX + rotOffset, centerY, urnWidth + 20, 0, Math.PI * 2);
      ctx.fill();
    };

    const animate = () => {
      rotationRef.current += 1;
      draw();
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [scan]);

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={500}
        height={400}
        className="w-full rounded-lg"
      />
      <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-md bg-black/70 px-2 py-1 text-xs text-white">
        <RotateCcw className="h-3 w-3 animate-spin" style={{ animationDuration: "3s" }} />
        Auto-rotating view
      </div>
    </div>
  );
}

export function ScanResultsTable({
  scans,
  onViewScan,
  onDeleteScan,
  onExportScan,
  isLoading,
}: ScanResultsTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [viewingScan, setViewingScan] = useState<GPRScan | null>(null);

  const toggleRow = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  const handleViewScan = (scan: GPRScan) => {
    setViewingScan(scan);
    onViewScan?.(scan);
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const formatCoordinates = (lat: number, lng: number) => {
    return `${lat.toFixed(4)}°, ${lng.toFixed(4)}°`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-medium">
            <FileText className="h-5 w-5 text-primary" />
            Scan Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 animate-pulse rounded-md bg-muted" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Dialog open={viewingScan !== null} onOpenChange={() => setViewingScan(null)}>
        <DialogContent className="max-w-2xl" data-testid="dialog-3d-scan">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2" data-testid="dialog-title-3d-scan">
              <Eye className="h-5 w-5 text-primary" />
              3D Scan Visualization
            </DialogTitle>
          </DialogHeader>
          {viewingScan && (
            <div className="space-y-4">
              <Scan3DViewer scan={viewingScan} />
              <div className="grid grid-cols-2 gap-4 rounded-lg border border-border bg-muted/50 p-4">
                <div>
                  <span className="text-xs text-muted-foreground">Timestamp</span>
                  <p className="font-mono text-sm">{formatDate(viewingScan.timestamp)}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">GPS Coordinates</span>
                  <p className="font-mono text-sm">{formatCoordinates(viewingScan.gpsLat, viewingScan.gpsLng)}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Depth</span>
                  <p className="font-mono text-sm">{viewingScan.depth.toFixed(2)}m</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Confidence</span>
                  <p className="font-mono text-sm">{(viewingScan.confidenceScore * 100).toFixed(1)}%</p>
                </div>
                <div className="col-span-2">
                  <span className="text-xs text-muted-foreground">Notes</span>
                  <p className="text-sm">{viewingScan.notes || "No notes"}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-lg font-medium">
            <FileText className="h-5 w-5 text-primary" />
            Scan Results
            <Badge variant="secondary" className="ml-2">
              {scans.length}
            </Badge>
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" data-testid="button-export-all">
              <Download className="mr-2 h-4 w-4" />
              Export All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {scans.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="mb-4 h-12 w-12 text-muted-foreground/50" />
              <h3 className="text-lg font-medium">No scan results yet</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Start a GPR scan to begin collecting data
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8"></TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>GPS Coordinates</TableHead>
                    <TableHead>Depth</TableHead>
                    <TableHead>Confidence</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scans.map((scan) => (
                    <Fragment key={scan.id}>
                      <TableRow
                        className={cn(
                          "cursor-pointer transition-colors",
                          expandedRows.has(scan.id) && "bg-muted/50"
                        )}
                        onClick={() => toggleRow(scan.id)}
                        data-testid={`row-scan-${scan.id}`}
                      >
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-6 w-6">
                            {expandedRows.has(scan.id) ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </Button>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {formatDate(scan.timestamp)}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {formatCoordinates(scan.gpsLat, scan.gpsLng)}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {scan.depth.toFixed(2)}m
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={scan.confidenceScore > 0.7 ? "default" : "secondary"}
                          >
                            {(scan.confidenceScore * 100).toFixed(0)}%
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {scan.artifactDetected ? (
                            <Badge className="bg-yellow-500/20 text-yellow-600 dark:text-yellow-400">
                              Artifact Detected
                            </Badge>
                          ) : (
                            <Badge variant="secondary">No Detection</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleViewScan(scan)}
                              data-testid={`button-view-scan-${scan.id}`}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => onExportScan?.(scan)}
                              data-testid={`button-export-scan-${scan.id}`}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => onDeleteScan?.(scan.id)}
                              data-testid={`button-delete-scan-${scan.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                      {expandedRows.has(scan.id) && (
                        <TableRow key={`${scan.id}-details`}>
                          <TableCell colSpan={7} className="bg-muted/30 p-4">
                            <div className="grid gap-4 md:grid-cols-2">
                              <div>
                                <h4 className="mb-2 text-sm font-medium">Notes</h4>
                                <p className="text-sm text-muted-foreground">
                                  {scan.notes || "No notes added"}
                                </p>
                              </div>
                              <div>
                                <h4 className="mb-2 text-sm font-medium">Quick Preview</h4>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleViewScan(scan)}
                                  className="w-full"
                                >
                                  <Eye className="mr-2 h-4 w-4" />
                                  View 3D Reconstruction
                                </Button>
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
