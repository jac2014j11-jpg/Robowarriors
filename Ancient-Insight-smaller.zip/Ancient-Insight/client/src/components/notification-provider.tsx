import { createContext, useContext, useState, useCallback, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import type { GPRScan } from "@shared/schema";

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  type: "artifact" | "scan" | "system";
}

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, "id" | "timestamp" | "read">) => void;
  markAsRead: (id: string) => void;
  clearAll: () => void;
  unreadCount: number;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "welcome",
      title: "System Online",
      message: "Smart Integrated Rover (SIR) is connected and ready for operation.",
      timestamp: new Date(Date.now() - 300000),
      read: false,
      type: "system",
    },
  ]);
  const [lastScansLength, setLastScansLength] = useState<number | null>(null);
  const { toast } = useToast();

  const { data: scans } = useQuery<GPRScan[]>({
    queryKey: ["/api/scans"],
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (scans && lastScansLength !== null) {
      const newScans = scans.filter((scan) => scan.artifactDetected);
      if (newScans.length > 0 && scans.length > lastScansLength) {
        const latestScan = newScans[0];
        if (latestScan.artifactDetected) {
          const newNotification: Notification = {
            id: `artifact-${latestScan.id}`,
            title: "Artifact Detected",
            message: `Potential artifact found at depth ${latestScan.depth.toFixed(2)}m with ${(latestScan.confidenceScore * 100).toFixed(0)}% confidence.`,
            timestamp: new Date(),
            read: false,
            type: "artifact",
          };
          setNotifications((prev) => [newNotification, ...prev]);
          toast({
            title: "Artifact Detected",
            description: `Confidence: ${(latestScan.confidenceScore * 100).toFixed(0)}%`,
          });
        }
      }
    }
    if (scans) {
      setLastScansLength(scans.length);
    }
  }, [scans, lastScansLength, toast]);

  const addNotification = useCallback(
    (notification: Omit<Notification, "id" | "timestamp" | "read">) => {
      const newNotification: Notification = {
        ...notification,
        id: `notif-${Date.now()}`,
        timestamp: new Date(),
        read: false,
      };
      setNotifications((prev) => [newNotification, ...prev]);
    },
    []
  );

  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{ notifications, addNotification, markAsRead, clearAll, unreadCount }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotifications must be used within NotificationProvider");
  }
  return context;
}
