import { Card, CardContent } from "@/components/ui/card";
import { Battery, Wifi, MapPin, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import type { RoverStatus } from "@shared/schema";

interface StatusDashboardProps {
  status: RoverStatus | undefined;
  isLoading?: boolean;
}

interface MetricCardProps {
  icon: React.ElementType;
  label: string;
  value: string | number;
  unit?: string;
  iconColor: string;
  iconBg: string;
}

function MetricCard({ icon: Icon, label, value, unit, iconColor, iconBg }: MetricCardProps) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-4">
        <div className={cn("flex h-12 w-12 items-center justify-center rounded-lg", iconBg)}>
          <Icon className={cn("h-6 w-6", iconColor)} />
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold">{value}</span>
            {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function StatusDashboard({ status, isLoading }: StatusDashboardProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="h-12 w-12 animate-pulse rounded-lg bg-muted" />
              <div className="space-y-2">
                <div className="h-3 w-16 animate-pulse rounded bg-muted" />
                <div className="h-6 w-12 animate-pulse rounded bg-muted" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const getBatteryColor = (level: number) => {
    if (level > 60) return { color: "text-green-500", bg: "bg-green-500/20" };
    if (level > 30) return { color: "text-yellow-500", bg: "bg-yellow-500/20" };
    return { color: "text-red-500", bg: "bg-red-500/20" };
  };

  const getSignalColor = (strength: number) => {
    if (strength > 70) return { color: "text-green-500", bg: "bg-green-500/20" };
    if (strength > 40) return { color: "text-yellow-500", bg: "bg-yellow-500/20" };
    return { color: "text-red-500", bg: "bg-red-500/20" };
  };

  const batteryColors = getBatteryColor(status?.batteryLevel || 0);
  const signalColors = getSignalColor(status?.signalStrength || 0);

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      <MetricCard
        icon={Battery}
        label="Battery"
        value={(status?.batteryLevel || 0).toFixed(2)}
        unit="%"
        iconColor={batteryColors.color}
        iconBg={batteryColors.bg}
      />
      <MetricCard
        icon={Wifi}
        label="Signal"
        value={Math.round(status?.signalStrength || 0)}
        unit="%"
        iconColor={signalColors.color}
        iconBg={signalColors.bg}
      />
      <MetricCard
        icon={MapPin}
        label="GPS Lock"
        value={status?.gpsLat && status?.gpsLng ? "Active" : "No Lock"}
        iconColor="text-blue-500"
        iconBg="bg-blue-500/20"
      />
      <MetricCard
        icon={Activity}
        label="Active Scans"
        value={status?.activeScans || 0}
        iconColor="text-purple-500"
        iconBg="bg-purple-500/20"
      />
    </div>
  );
}
