import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { GPRViewer } from "@/components/gpr-viewer";
import { ScanResultsTable } from "@/components/scan-results-table";
import { useToast } from "@/hooks/use-toast";
import {
  Scan,
  Settings2,
  Layers,
  ZoomIn,
  Grid3X3,
  Maximize,
} from "lucide-react";
import type { RoverStatus, GPRScan } from "@shared/schema";

export default function Scanner() {
  const { toast } = useToast();
  const [resolution, setResolution] = useState([75]);
  const [depthRange, setDepthRange] = useState([0, 100]);
  const [showGrid, setShowGrid] = useState(true);
  const [autoProcess, setAutoProcess] = useState(true);

  const { data: roverStatus } = useQuery<RoverStatus>({
    queryKey: ["/api/rover/status"],
    refetchInterval: 2000,
  });

  const { data: scans = [], isLoading: isLoadingScans } = useQuery<GPRScan[]>({
    queryKey: ["/api/scans"],
  });

  const { data: currentScan } = useQuery<GPRScan>({
    queryKey: ["/api/scans/current"],
    refetchInterval: roverStatus?.activeScans ? 1000 : false,
    retry: false,
  });

  const startScanMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scans/start", {
        resolution: resolution[0],
        depthMin: depthRange[0],
        depthMax: depthRange[1],
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rover/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      toast({
        title: "Scan Started",
        description: "GPR scanning is now active with custom settings",
      });
    },
  });

  const stopScanMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/scans/stop", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rover/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      toast({
        title: "Scan Stopped",
        description: "GPR scanning has been stopped",
      });
    },
  });

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold">GPR Scanner</h1>
        <p className="text-sm text-muted-foreground">
          Configure and monitor ground-penetrating radar scans
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Tabs defaultValue="live" className="space-y-4">
            <TabsList>
              <TabsTrigger value="live" data-testid="tab-live-view">
                <Scan className="mr-2 h-4 w-4" />
                Live View
              </TabsTrigger>
              <TabsTrigger value="3d" data-testid="tab-3d-view">
                <Layers className="mr-2 h-4 w-4" />
                3D Reconstruction
              </TabsTrigger>
              <TabsTrigger value="compare" data-testid="tab-compare-view">
                <Grid3X3 className="mr-2 h-4 w-4" />
                Compare
              </TabsTrigger>
            </TabsList>

            <TabsContent value="live">
              <GPRViewer
                scan={currentScan}
                isScanning={Boolean(roverStatus?.activeScans)}
                onStartScan={() => startScanMutation.mutate()}
                onStopScan={() => stopScanMutation.mutate()}
              />
            </TabsContent>

            <TabsContent value="3d">
              <Card>
                <CardContent className="flex aspect-video items-center justify-center">
                  <div className="text-center">
                    <Layers className="mx-auto mb-4 h-16 w-16 text-muted-foreground/30" />
                    <h3 className="text-lg font-medium">3D Reconstruction</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Select a scan to view 3D volumetric reconstruction
                    </p>
                    <Button variant="outline" className="mt-4">
                      <ZoomIn className="mr-2 h-4 w-4" />
                      Load Recent Scan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="compare">
              <Card>
                <CardContent className="flex aspect-video items-center justify-center">
                  <div className="text-center">
                    <Grid3X3 className="mx-auto mb-4 h-16 w-16 text-muted-foreground/30" />
                    <h3 className="text-lg font-medium">Compare Scans</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Select two scans to compare side by side
                    </p>
                    <Button variant="outline" className="mt-4">
                      <Maximize className="mr-2 h-4 w-4" />
                      Select Scans
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg font-medium">
                <Settings2 className="h-5 w-5 text-primary" />
                Scan Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Resolution</Label>
                  <span className="font-mono text-sm text-muted-foreground">
                    {resolution[0]}%
                  </span>
                </div>
                <Slider
                  value={resolution}
                  onValueChange={setResolution}
                  min={25}
                  max={100}
                  step={5}
                  data-testid="slider-resolution"
                />
                <p className="text-xs text-muted-foreground">
                  Higher resolution increases scan detail but takes longer
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Depth Range</Label>
                  <span className="font-mono text-sm text-muted-foreground">
                    {depthRange[0]}% - {depthRange[1]}%
                  </span>
                </div>
                <Slider
                  value={depthRange}
                  onValueChange={setDepthRange}
                  min={0}
                  max={100}
                  step={5}
                  data-testid="slider-depth-range"
                />
                <p className="text-xs text-muted-foreground">
                  Adjust the scanning depth for the GPR antenna
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Show Grid Overlay</Label>
                  <p className="text-xs text-muted-foreground">
                    Display reference grid on scan
                  </p>
                </div>
                <Switch
                  checked={showGrid}
                  onCheckedChange={setShowGrid}
                  data-testid="switch-show-grid"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Auto-Process</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically detect artifacts
                  </p>
                </div>
                <Switch
                  checked={autoProcess}
                  onCheckedChange={setAutoProcess}
                  data-testid="switch-auto-process"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total Scans</span>
                <span className="font-mono font-medium">{scans.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Artifacts Found</span>
                <span className="font-mono font-medium">
                  {scans.filter((s) => s.artifactDetected).length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Avg. Confidence</span>
                <span className="font-mono font-medium">
                  {scans.length > 0
                    ? (
                        (scans.reduce((acc, s) => acc + s.confidenceScore, 0) /
                          scans.length) *
                        100
                      ).toFixed(1)
                    : 0}
                  %
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <ScanResultsTable
        scans={scans}
        onViewScan={(scan) =>
          toast({ title: "Viewing Scan", description: `ID: ${scan.id}` })
        }
        onDeleteScan={(id) =>
          toast({ title: "Scan Deleted", description: `ID: ${id}` })
        }
        onExportScan={(scan) =>
          toast({ title: "Exporting Scan", description: `ID: ${scan.id}` })
        }
        isLoading={isLoadingScans}
      />
    </div>
  );
}
