import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Settings,
  Bell,
  Shield,
  Database,
  Wifi,
  Sun,
  Battery,
  Radio,
  Satellite,
} from "lucide-react";
import { useState } from "react";

export default function SettingsPage() {
  const [notifications, setNotifications] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [lowPowerMode, setLowPowerMode] = useState(false);

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Configure your rover and application preferences
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-medium">
              <Bell className="h-5 w-5 text-primary" />
              Notifications
            </CardTitle>
            <CardDescription>
              Configure how you receive alerts and updates
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Push Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Receive alerts for scan completions and discoveries
                </p>
              </div>
              <Switch
                checked={notifications}
                onCheckedChange={setNotifications}
                data-testid="switch-notifications"
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Low Battery Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Get notified when rover battery is below 20%
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-battery-alerts" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Artifact Detection</Label>
                <p className="text-xs text-muted-foreground">
                  Alert when potential artifacts are detected
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-artifact-alerts" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-medium">
              <Wifi className="h-5 w-5 text-primary" />
              Communication
            </CardTitle>
            <CardDescription>
              Configure rover communication settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">LoRa WAN Frequency</Label>
              <Select defaultValue="915">
                <SelectTrigger data-testid="select-lora-frequency">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="868">868 MHz (EU)</SelectItem>
                  <SelectItem value="915">915 MHz (US)</SelectItem>
                  <SelectItem value="433">433 MHz (Asia)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Separator />
            <div className="space-y-2">
              <Label className="text-sm font-medium">Starlink Priority</Label>
              <Select defaultValue="balanced">
                <SelectTrigger data-testid="select-starlink-priority">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low-latency">Low Latency</SelectItem>
                  <SelectItem value="balanced">Balanced</SelectItem>
                  <SelectItem value="high-throughput">High Throughput</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Auto-Reconnect</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically reconnect on signal loss
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-auto-reconnect" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-medium">
              <Sun className="h-5 w-5 text-primary" />
              Power Management
            </CardTitle>
            <CardDescription>
              Configure rover power and solar panel settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Low Power Mode</Label>
                <p className="text-xs text-muted-foreground">
                  Reduce scan frequency to conserve battery
                </p>
              </div>
              <Switch
                checked={lowPowerMode}
                onCheckedChange={setLowPowerMode}
                data-testid="switch-low-power"
              />
            </div>
            <Separator />
            <div className="space-y-2">
              <Label className="text-sm font-medium">Solar Charging Mode</Label>
              <Select defaultValue="auto">
                <SelectTrigger data-testid="select-solar-mode">
                  <SelectValue placeholder="Select mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Automatic</SelectItem>
                  <SelectItem value="max-charge">Maximum Charging</SelectItem>
                  <SelectItem value="balanced">Balanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Separator />
            <div className="space-y-2">
              <Label className="text-sm font-medium">Minimum Battery for Scan</Label>
              <Select defaultValue="15">
                <SelectTrigger data-testid="select-min-battery">
                  <SelectValue placeholder="Select percentage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10%</SelectItem>
                  <SelectItem value="15">15%</SelectItem>
                  <SelectItem value="20">20%</SelectItem>
                  <SelectItem value="25">25%</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-medium">
              <Database className="h-5 w-5 text-primary" />
              Data Storage
            </CardTitle>
            <CardDescription>
              Configure data storage and backup settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Auto-Save Scans</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically save all scan data locally
                </p>
              </div>
              <Switch
                checked={autoSave}
                onCheckedChange={setAutoSave}
                data-testid="switch-auto-save"
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Cloud Backup</Label>
                <p className="text-xs text-muted-foreground">
                  Sync data to cloud when connected
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-cloud-backup" />
            </div>
            <Separator />
            <div className="space-y-2">
              <Label className="text-sm font-medium">Export Format</Label>
              <Select defaultValue="json">
                <SelectTrigger data-testid="select-export-format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="geojson">GeoJSON</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-medium">
            <Shield className="h-5 w-5 text-primary" />
            Safety & Security
          </CardTitle>
          <CardDescription>
            Configure safety limits and security settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label className="text-sm font-medium">Maximum Speed Limit</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  defaultValue="100"
                  className="flex-1"
                  data-testid="input-max-speed"
                />
                <span className="flex items-center text-sm text-muted-foreground">
                  cm/s
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">Geofence Radius</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  defaultValue="500"
                  className="flex-1"
                  data-testid="input-geofence"
                />
                <span className="flex items-center text-sm text-muted-foreground">
                  meters
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button variant="outline" data-testid="button-reset-settings">
          Reset to Defaults
        </Button>
        <Button data-testid="button-save-settings">Save Settings</Button>
      </div>
    </div>
  );
}
