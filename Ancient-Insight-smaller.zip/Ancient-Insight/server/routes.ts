import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import { storage } from "./storage";
import { roverCommandSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/artifacts/images/:filename", (req, res) => {
    const filename = req.params.filename;
    const imagePath = path.join(process.cwd(), "attached_assets", "generated_images", filename);
    res.sendFile(imagePath, (err) => {
      if (err) {
        res.status(404).json({ error: "Image not found" });
      }
    });
  });

  app.get("/api/rover/status", async (req, res) => {
    try {
      const status = await storage.getRoverStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to get rover status" });
    }
  });

  app.post("/api/rover/command", async (req, res) => {
    try {
      const result = roverCommandSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid command", details: result.error.errors });
      }

      const command = result.data;
      const currentStatus = await storage.getRoverStatus();

      switch (command.type) {
        case "toggle_solar":
          await storage.updateRoverStatus({ solarPanelActive: !currentStatus.solarPanelActive });
          break;
        case "toggle_lora":
          await storage.updateRoverStatus({ loraWanActive: !currentStatus.loraWanActive });
          break;
        case "toggle_starlink":
          await storage.updateRoverStatus({ starlinkConnected: !currentStatus.starlinkConnected });
          break;
        case "toggle_manual":
          await storage.updateRoverStatus({ manualOverride: !currentStatus.manualOverride });
          break;
        case "toggle_gpr":
          await storage.updateRoverStatus({ gprActive: !currentStatus.gprActive });
          break;
        case "set_speed":
          if (typeof command.value === "number") {
            await storage.updateRoverStatus({ speed: command.value });
          }
          break;
        case "move":
          const deltaLat = command.direction === "forward" ? 0.0001 : command.direction === "backward" ? -0.0001 : 0;
          const deltaLng = command.direction === "right" ? 0.0001 : command.direction === "left" ? -0.0001 : 0;
          await storage.updateRoverStatus({
            gpsLat: currentStatus.gpsLat + deltaLat,
            gpsLng: currentStatus.gpsLng + deltaLng,
          });
          break;
        case "stop":
          break;
        case "start_scan":
          storage.startScan();
          break;
        case "stop_scan":
          storage.stopScan();
          break;
      }

      const updatedStatus = await storage.getRoverStatus();
      res.json({ success: true, status: updatedStatus });
    } catch (error) {
      res.status(500).json({ error: "Failed to execute command" });
    }
  });

  app.get("/api/scans", async (req, res) => {
    try {
      const scans = await storage.getScans();
      res.json(scans);
    } catch (error) {
      res.status(500).json({ error: "Failed to get scans" });
    }
  });

  app.get("/api/scans/current", async (req, res) => {
    try {
      const scan = await storage.getCurrentScan();
      if (!scan) {
        return res.status(404).json({ error: "No active scan" });
      }
      res.json(scan);
    } catch (error) {
      res.status(500).json({ error: "Failed to get current scan" });
    }
  });

  app.get("/api/scans/:id", async (req, res) => {
    try {
      const scan = await storage.getScan(req.params.id);
      if (!scan) {
        return res.status(404).json({ error: "Scan not found" });
      }
      res.json(scan);
    } catch (error) {
      res.status(500).json({ error: "Failed to get scan" });
    }
  });

  app.post("/api/scans/start", async (req, res) => {
    try {
      const scan = storage.startScan();
      res.json(scan);
    } catch (error) {
      res.status(500).json({ error: "Failed to start scan" });
    }
  });

  app.post("/api/scans/stop", async (req, res) => {
    try {
      storage.stopScan();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to stop scan" });
    }
  });

  app.delete("/api/scans/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteScan(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Scan not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete scan" });
    }
  });

  app.get("/api/artifacts", async (req, res) => {
    try {
      const { search } = req.query;
      let artifacts;
      
      if (search && typeof search === "string") {
        artifacts = await storage.searchArtifacts(search);
      } else {
        artifacts = await storage.getArtifacts();
      }
      
      res.json(artifacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get artifacts" });
    }
  });

  app.get("/api/artifacts/:id", async (req, res) => {
    try {
      const artifact = await storage.getArtifact(req.params.id);
      if (!artifact) {
        return res.status(404).json({ error: "Artifact not found" });
      }
      res.json(artifact);
    } catch (error) {
      res.status(500).json({ error: "Failed to get artifact" });
    }
  });

  return httpServer;
}
