# Design Guidelines: Archaeological Rover Control Application

## Design Approach
**System**: Fluent Design + Carbon Design hybrid - optimized for data-heavy professional applications with real-time control interfaces. Drawing from mission control dashboards and scientific data visualization tools.

## Core Layout Structure

### Primary Dashboard Layout
- **Grid System**: 12-column grid with 3-panel layout
  - Left sidebar (3 cols): Rover controls and status
  - Center panel (6 cols): Live GPR feed and map view
  - Right panel (3 cols): Data stream and notifications
- **Responsive breakpoint**: Below 1280px, stack to single column with tabbed navigation

### Spacing System
Use Tailwind units: **2, 3, 4, 6, 8, 12** for consistent rhythm
- Component padding: p-4 to p-6
- Section spacing: gap-6 to gap-8
- Panel margins: m-3 to m-4
- Compact data displays: p-2 to p-3

## Typography Hierarchy

**Fonts**: 
- Primary: "Inter" (UI, data, controls)
- Monospace: "JetBrains Mono" (coordinates, technical readouts)

**Scale**:
- Dashboard title: text-2xl font-semibold
- Panel headers: text-lg font-medium
- Control labels: text-sm font-medium uppercase tracking-wide
- Data readouts: text-base font-mono
- Status indicators: text-xs font-medium
- Coordinates/GPS: text-sm font-mono

## Component Library

### Navigation
- Top bar (h-16): Logo, mission status, user profile, emergency stop button
- Persistent across all views with breadcrumb trail

### Control Panels

**Rover Controls Card**:
- Segmented sections with 2px borders
- Toggle switches (h-6 w-11) for: Solar Panel, LoRa WAN, Starlink, Manual Override
- Status LEDs (w-3 h-3 rounded-full) next to each control
- Directional pad (grid of 3x3 buttons, each w-12 h-12)
- Speed slider with numeric readout

**System Status Dashboard**:
- 4-column grid of metric cards
- Each card: Icon (w-8 h-8), Label, Value (text-2xl font-bold), Unit (text-sm)
- Metrics: Battery %, Signal Strength, GPS Lock, Active Scans

### Data Visualization

**GPR Feed Viewer**:
- Canvas container (aspect-ratio-16/9, min-h-96)
- Control bar below: 2D/3D toggle, depth slider, resolution controls
- Timeline scrubber for historical data
- Split view option for side-by-side comparison

**Map Interface**:
- Full-width container with zoom controls (top-right, w-10 h-10 buttons)
- GPS coordinate overlay (bottom-left, font-mono text-sm)
- Artifact markers: Clickable pins with popup cards
- Grid overlay toggle

### Artifact Discovery Section

**Scan Results Table**:
- Dense table layout with sortable columns
- Columns: Timestamp, GPS Coordinates, Depth, Confidence Score, Preview
- Row height: h-16, zebra striping
- Expandable rows for detailed GPR images
- Batch actions toolbar

**Artifact Database Browser**:
- Search bar (h-12, full-width) with advanced filters dropdown
- Results as cards in 3-column grid (md:grid-cols-2 lg:grid-cols-3)
- Each card: Thumbnail (aspect-square), Title, Date, Location snippet
- "View Details" link opens modal with full information

### Modal Patterns
- Full artifact details: max-w-4xl centered modal
- Large image viewer (aspect-ratio-4/3), metadata table, external link button
- 3D viewer: Full-screen option, rotation controls, measurement tools

## Interaction Patterns

**Real-time Updates**:
- Pulsing indicator (animate-pulse) on active data streams
- Toast notifications (top-right corner, w-96) for system alerts
- Auto-refresh badge on stale data

**Emergency Controls**:
- Prominent "STOP ALL" button (h-14 w-full) in rover control panel
- Confirmation dialog for critical actions
- Lock/unlock toggle for safety

## Data Display Standards

**Coordinates Format**:
- GPS: DD.DDDD° format in monospace
- Grouping: Lat/Long/Elevation in single row with gap-4
- Copy-to-clipboard icon (w-4 h-4) on hover

**Status Indicators**:
- Three states: Active (checkmark icon), Inactive (minus icon), Error (alert icon)
- Icons: w-5 h-5 with corresponding label
- Grouped in compact horizontal lists with gap-3

## Images

**Artifact Gallery Images**:
- Thumbnail previews in database results (w-full aspect-square, object-cover)
- High-resolution images in detail modals
- GPR scan visualizations rendered programmatically (no static images)
- No hero images - this is a utility application

**Icons**: Use Heroicons (CDN) for all interface icons - outline style for controls, solid style for status indicators

## Accessibility
- All controls keyboard navigable with visible focus rings (ring-2)
- ARIA labels on all icon-only buttons
- High contrast for data readouts
- Screen reader announcements for status changes