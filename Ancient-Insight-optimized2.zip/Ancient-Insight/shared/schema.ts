import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export interface RoverStatus {
  id: string;
  name: string;
  batteryLevel: number;
  solarPanelActive: boolean;
  loraWanActive: boolean;
  starlinkConnected: boolean;
  manualOverride: boolean;
  gprActive: boolean;
  gpsLat: number;
  gpsLng: number;
  gpsElevation: number;
  signalStrength: number;
  activeScans: number;
  speed: number;
  lastUpdated: string;
}

export interface RoverCommand {
  type: 'move' | 'stop' | 'toggle_solar' | 'toggle_lora' | 'toggle_starlink' | 'toggle_manual' | 'toggle_gpr' | 'set_speed' | 'start_scan' | 'stop_scan';
  direction?: 'forward' | 'backward' | 'left' | 'right';
  value?: number | boolean;
}

export interface GPRScan {
  id: string;
  timestamp: string;
  gpsLat: number;
  gpsLng: number;
  depth: number;
  confidenceScore: number;
  dataPoints: number[][];
  artifactDetected: boolean;
  notes: string;
}

export interface Artifact {
  id: string;
  name: string;
  description: string;
  dateFound: string;
  location: string;
  gpsLat: number;
  gpsLng: number;
  depth: number;
  period: string;
  category: string;
  imageUrl: string;
  externalLink: string;
  similarity: number;
}

export const insertGPRScanSchema = z.object({
  gpsLat: z.number(),
  gpsLng: z.number(),
  depth: z.number(),
  confidenceScore: z.number(),
  dataPoints: z.array(z.array(z.number())),
  artifactDetected: z.boolean(),
  notes: z.string(),
});

export type InsertGPRScan = z.infer<typeof insertGPRScanSchema>;

export const roverCommandSchema = z.object({
  type: z.enum(['move', 'stop', 'toggle_solar', 'toggle_lora', 'toggle_starlink', 'toggle_manual', 'toggle_gpr', 'set_speed', 'start_scan', 'stop_scan']),
  direction: z.enum(['forward', 'backward', 'left', 'right']).optional(),
  value: z.union([z.number(), z.boolean()]).optional(),
});

export type RoverCommandInput = z.infer<typeof roverCommandSchema>;
