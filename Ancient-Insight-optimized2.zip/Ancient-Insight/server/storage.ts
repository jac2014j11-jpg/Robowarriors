import { type User, type InsertUser, type RoverStatus, type GPRScan, type Artifact, type InsertGPRScan } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRoverStatus(): Promise<RoverStatus>;
  updateRoverStatus(updates: Partial<RoverStatus>): Promise<RoverStatus>;
  
  getScans(): Promise<GPRScan[]>;
  getScan(id: string): Promise<GPRScan | undefined>;
  getCurrentScan(): Promise<GPRScan | undefined>;
  createScan(scan: InsertGPRScan): Promise<GPRScan>;
  deleteScan(id: string): Promise<boolean>;
  
  getArtifacts(): Promise<Artifact[]>;
  getArtifact(id: string): Promise<Artifact | undefined>;
  searchArtifacts(query: string): Promise<Artifact[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private roverStatus: RoverStatus;
  private scans: Map<string, GPRScan>;
  private artifacts: Map<string, Artifact>;
  private currentScanId: string | null = null;

  constructor() {
    this.users = new Map();
    this.scans = new Map();
    this.artifacts = new Map();
    
    this.roverStatus = {
      id: "rover-001",
      name: "SIR-1",
      batteryLevel: 87,
      solarPanelActive: true,
      loraWanActive: true,
      starlinkConnected: true,
      manualOverride: false,
      gprActive: true,
      gpsLat: 31.1342,
      gpsLng: 29.9792,
      gpsElevation: 12.5,
      signalStrength: 92,
      activeScans: 0,
      speed: 50,
      lastUpdated: new Date().toISOString(),
    };

    this.initializeSampleArtifacts();
    this.initializeSampleScans();
  }

  private initializeSampleArtifacts() {
    const sampleArtifacts: Artifact[] = [
      {
        id: "art-001",
        name: "Ancient Wooden Vase",
        description: "A remarkably preserved wooden vase with visible grain texture and natural patina. The dark aged wood shows characteristic cracks and weathering patterns from centuries of burial. Used for ceremonial purposes.",
        dateFound: "2024-03-15",
        location: "Alexandria, Egypt",
        gpsLat: 31.2001,
        gpsLng: 29.9187,
        depth: 1.2,
        period: "Ptolemaic Period",
        category: "Wooden Vessels",
        imageUrl: "/api/artifacts/images/ancient_wooden_vase_artifact.png",
        externalLink: "https://www.britishmuseum.org/collection/object/G_1856-1226-1",
        similarity: 0.95,
      },
      {
        id: "art-002",
        name: "Ceremonial Ceramic Urn",
        description: "An ancient ceramic urn with decorative geometric patterns in terracotta. Features faded painted designs and slightly worn edges. Likely used for storing ritual offerings or cremation remains.",
        dateFound: "2023-11-08",
        location: "Luxor, Egypt",
        gpsLat: 25.6872,
        gpsLng: 32.6396,
        depth: 0.8,
        period: "New Kingdom",
        category: "Ceramic Vessels",
        imageUrl: "/api/artifacts/images/ancient_ceramic_urn_artifact.png",
        externalLink: "https://www.metmuseum.org/art/collection/search/544755",
        similarity: 0.91,
      },
      {
        id: "art-003",
        name: "Bronze Age Pottery Bowl",
        description: "A distinctive pottery bowl with geometric patterns in reddish-brown clay. Features black painted decorations typical of Bronze Age craftsmanship. Small chips and wear marks indicate regular use.",
        dateFound: "2024-01-22",
        location: "Cairo, Egypt",
        gpsLat: 30.0444,
        gpsLng: 31.2357,
        depth: 0.5,
        period: "Bronze Age",
        category: "Pottery",
        imageUrl: "/api/artifacts/images/bronze_age_pottery_bowl.png",
        externalLink: "https://www.coinarchives.com/w/lotviewer.php?LotID=1234567",
        similarity: 0.87,
      },
      {
        id: "art-004",
        name: "Egyptian Scarab Amulet",
        description: "Faience scarab beetle amulet with hieroglyphic inscription on the base. Blue-green glaze well preserved. Pierced longitudinally for stringing as protective jewelry.",
        dateFound: "2024-02-10",
        location: "Saqqara, Egypt",
        gpsLat: 29.9753,
        gpsLng: 31.1376,
        depth: 1.5,
        period: "New Kingdom",
        category: "Jewelry",
        imageUrl: "/api/artifacts/images/egyptian_scarab_amulet.png",
        externalLink: "https://www.louvre.fr/en/oeuvre-notices/scarab",
        similarity: 0.88,
      },
      {
        id: "art-005",
        name: "Roman Amphora Fragment",
        description: "A well-preserved fragment of a Roman amphora in terracotta. Shows visible pottery marks and handle attachment point. Aged patina and soil staining indicate long burial period.",
        dateFound: "2023-09-05",
        location: "Giza, Egypt",
        gpsLat: 29.8713,
        gpsLng: 31.2165,
        depth: 0.9,
        period: "Roman Period",
        category: "Pottery",
        imageUrl: "/api/artifacts/images/roman_amphora_fragment.png",
        externalLink: "https://www.brooklynmuseum.org/opencollection/objects/3565",
        similarity: 0.82,
      },
      {
        id: "art-006",
        name: "Bronze Arrowhead",
        description: "Triangular bronze arrowhead with distinctive green patina oxidation. Sharp pointed tip with evidence of casting mold lines. Minimal corrosion due to dry burial conditions.",
        dateFound: "2024-04-01",
        location: "Abydos, Egypt",
        gpsLat: 26.1849,
        gpsLng: 31.9021,
        depth: 2.1,
        period: "Bronze Age",
        category: "Weapons",
        imageUrl: "/api/artifacts/images/bronze_arrowhead_artifact.png",
        externalLink: "https://www.penn.museum/collections/object/123456",
        similarity: 0.78,
      },
      {
        id: "art-007",
        name: "Ptolemaic Silver Coin",
        description: "Silver tetradrachm featuring a portrait profile with Greek letters. Worn but legible details with characteristic tarnished patina. Reverse shows an eagle standing on a thunderbolt.",
        dateFound: "2023-12-18",
        location: "Alexandria, Egypt",
        gpsLat: 31.2156,
        gpsLng: 29.9553,
        depth: 0.7,
        period: "Ptolemaic Period",
        category: "Coins",
        imageUrl: "/api/artifacts/images/ancient_silver_coin.png",
        externalLink: "https://www.corningmuseum.org/collection/123456",
        similarity: 0.85,
      },
      {
        id: "art-008",
        name: "Terracotta Oil Lamp",
        description: "Intact terracotta oil lamp with single nozzle design. Features decorative relief pattern with visible soot marks from use. Aged surface indicates regular domestic use.",
        dateFound: "2024-02-28",
        location: "Thebes, Egypt",
        gpsLat: 25.7189,
        gpsLng: 32.6107,
        depth: 1.1,
        period: "Late Antique",
        category: "Household",
        imageUrl: "/api/artifacts/images/ancient_oil_lamp_artifact.png",
        externalLink: "https://www.mfa.org/collections/object/12345",
        similarity: 0.71,
      },
    ];

    sampleArtifacts.forEach((artifact) => {
      this.artifacts.set(artifact.id, artifact);
    });
  }

  private initializeSampleScans() {
    const now = new Date();
    const sampleScans: GPRScan[] = [
      {
        id: "scan-001",
        timestamp: new Date(now.getTime() - 3600000).toISOString(),
        gpsLat: 31.1342,
        gpsLng: 29.9792,
        depth: 1.2,
        confidenceScore: 0.95,
        dataPoints: this.generateVasePattern(),
        artifactDetected: true,
        notes: "Wooden Vase - Strong vase-shaped reflection at 1.2m depth with characteristic rounded profile",
      },
      {
        id: "scan-002",
        timestamp: new Date(now.getTime() - 7200000).toISOString(),
        gpsLat: 31.1345,
        gpsLng: 29.9795,
        depth: 0.8,
        confidenceScore: 0.91,
        dataPoints: this.generateUrnPattern(),
        artifactDetected: true,
        notes: "Ceramic Urn - Wide-body vessel signature detected, consistent with burial urn profile",
      },
      {
        id: "scan-003",
        timestamp: new Date(now.getTime() - 10800000).toISOString(),
        gpsLat: 31.1340,
        gpsLng: 29.9788,
        depth: 0.5,
        confidenceScore: 0.87,
        dataPoints: this.generateBowlPattern(),
        artifactDetected: true,
        notes: "Pottery Bowl - Shallow curved reflection indicating ceramic bowl artifact",
      },
      {
        id: "scan-004",
        timestamp: new Date(now.getTime() - 14400000).toISOString(),
        gpsLat: 31.1348,
        gpsLng: 29.9800,
        depth: 1.5,
        confidenceScore: 0.62,
        dataPoints: this.generateGenericPattern(),
        artifactDetected: false,
        notes: "Natural rock formation - Irregular reflection pattern, likely geological",
      },
    ];

    sampleScans.forEach((scan) => {
      this.scans.set(scan.id, scan);
    });
  }

  private generateVasePattern(): number[][] {
    const rows = 50;
    const cols = 80;
    const data: number[][] = [];
    
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        let value = Math.random() * 30 + 20;
        const centerJ = cols / 2;
        const relI = i / rows;
        
        let vaseWidth = 0;
        if (relI < 0.2) {
          vaseWidth = 5 + relI * 25;
        } else if (relI < 0.4) {
          vaseWidth = 10 + (relI - 0.2) * 40;
        } else if (relI < 0.7) {
          vaseWidth = 18 - (relI - 0.4) * 20;
        } else {
          vaseWidth = 12 + (relI - 0.7) * 30;
        }
        
        const distFromCenter = Math.abs(j - centerJ);
        if (distFromCenter < vaseWidth) {
          const intensity = (1 - distFromCenter / vaseWidth) * 180;
          value += intensity;
        }
        
        row.push(Math.min(255, value));
      }
      data.push(row);
    }
    
    return data;
  }

  private generateUrnPattern(): number[][] {
    const rows = 50;
    const cols = 80;
    const data: number[][] = [];
    
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        let value = Math.random() * 30 + 20;
        const centerJ = cols / 2;
        const relI = i / rows;
        
        let urnWidth = 0;
        if (relI < 0.15) {
          urnWidth = 8;
        } else if (relI < 0.3) {
          urnWidth = 8 + (relI - 0.15) * 100;
        } else if (relI < 0.7) {
          urnWidth = 23;
        } else {
          urnWidth = 23 - (relI - 0.7) * 60;
        }
        
        const distFromCenter = Math.abs(j - centerJ);
        if (distFromCenter < urnWidth) {
          const intensity = (1 - distFromCenter / urnWidth) * 200;
          value += intensity;
        }
        
        row.push(Math.min(255, value));
      }
      data.push(row);
    }
    
    return data;
  }

  private generateBowlPattern(): number[][] {
    const rows = 50;
    const cols = 80;
    const data: number[][] = [];
    
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        let value = Math.random() * 30 + 20;
        const centerJ = cols / 2;
        const centerI = rows * 0.6;
        
        const distI = i - centerI;
        const distJ = j - centerJ;
        const radius = Math.sqrt(distI * distI * 0.5 + distJ * distJ);
        
        if (radius < 25 && i > rows * 0.3) {
          const intensity = (1 - radius / 25) * 160;
          value += intensity;
        }
        
        row.push(Math.min(255, value));
      }
      data.push(row);
    }
    
    return data;
  }

  private generateGenericPattern(): number[][] {
    const rows = 50;
    const cols = 80;
    const data: number[][] = [];
    
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        let value = Math.random() * 50 + 20;
        
        if (Math.random() > 0.85) {
          value += Math.random() * 80;
        }
        
        row.push(Math.min(255, value));
      }
      data.push(row);
    }
    
    return data;
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getRoverStatus(): Promise<RoverStatus> {
    this.roverStatus.lastUpdated = new Date().toISOString();
    
    if (this.roverStatus.solarPanelActive && this.roverStatus.batteryLevel < 100) {
      this.roverStatus.batteryLevel = Math.min(100, this.roverStatus.batteryLevel + 0.1);
    }
    
    this.roverStatus.signalStrength = Math.max(70, Math.min(100, 
      this.roverStatus.signalStrength + (Math.random() - 0.5) * 5
    ));
    
    return { ...this.roverStatus };
  }

  async updateRoverStatus(updates: Partial<RoverStatus>): Promise<RoverStatus> {
    this.roverStatus = { ...this.roverStatus, ...updates, lastUpdated: new Date().toISOString() };
    return { ...this.roverStatus };
  }

  async getScans(): Promise<GPRScan[]> {
    return Array.from(this.scans.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async getScan(id: string): Promise<GPRScan | undefined> {
    return this.scans.get(id);
  }

  async getCurrentScan(): Promise<GPRScan | undefined> {
    if (!this.currentScanId) return undefined;
    return this.scans.get(this.currentScanId);
  }

  async createScan(insertScan: InsertGPRScan): Promise<GPRScan> {
    const id = randomUUID();
    const scan: GPRScan = {
      id,
      timestamp: new Date().toISOString(),
      ...insertScan,
    };
    this.scans.set(id, scan);
    this.currentScanId = id;
    return scan;
  }

  async deleteScan(id: string): Promise<boolean> {
    return this.scans.delete(id);
  }

  startScan(): GPRScan {
    const patterns = [
      { generator: () => this.generateVasePattern(), name: "Wooden Vase", confidence: 0.95 },
      { generator: () => this.generateUrnPattern(), name: "Ceramic Urn", confidence: 0.91 },
      { generator: () => this.generateBowlPattern(), name: "Pottery Bowl", confidence: 0.87 },
      { generator: () => this.generateGenericPattern(), name: "Unknown", confidence: 0.5 },
    ];
    
    const selectedPattern = patterns[Math.floor(Math.random() * patterns.length)];
    const artifactDetected = selectedPattern.name !== "Unknown" && Math.random() > 0.3;
    
    const scan: GPRScan = {
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      gpsLat: this.roverStatus.gpsLat,
      gpsLng: this.roverStatus.gpsLng,
      depth: Math.random() * 2 + 0.5,
      confidenceScore: artifactDetected ? selectedPattern.confidence : 0.4 + Math.random() * 0.2,
      dataPoints: selectedPattern.generator(),
      artifactDetected,
      notes: artifactDetected ? `${selectedPattern.name} - Potential artifact detected` : "No significant artifact signature",
    };
    this.scans.set(scan.id, scan);
    this.currentScanId = scan.id;
    this.roverStatus.activeScans = 1;
    return scan;
  }

  stopScan(): void {
    this.currentScanId = null;
    this.roverStatus.activeScans = 0;
  }

  async getArtifacts(): Promise<Artifact[]> {
    return Array.from(this.artifacts.values()).sort((a, b) => b.similarity - a.similarity);
  }

  async getArtifact(id: string): Promise<Artifact | undefined> {
    return this.artifacts.get(id);
  }

  async searchArtifacts(query: string): Promise<Artifact[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.artifacts.values()).filter(
      (artifact) =>
        artifact.name.toLowerCase().includes(lowerQuery) ||
        artifact.description.toLowerCase().includes(lowerQuery) ||
        artifact.location.toLowerCase().includes(lowerQuery) ||
        artifact.category.toLowerCase().includes(lowerQuery) ||
        artifact.period.toLowerCase().includes(lowerQuery)
    );
  }
}

export const storage = new MemStorage();
