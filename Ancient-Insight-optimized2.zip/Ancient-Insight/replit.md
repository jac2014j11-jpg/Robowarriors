# replit.md

## Overview

ArchaeoRover Control is a professional web application for controlling and monitoring archaeological ground-penetrating radar (GPR) survey rovers. The system provides a real-time dashboard for rover control, GPR scanning visualization, artifact database management, and system settings. It's designed as a mission control-style interface for solar-powered rovers equipped with LoRaWAN and Starlink connectivity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Build Tool**: Vite with React plugin

The frontend follows a component-based architecture with:
- Pages in `client/src/pages/` (Dashboard, Scanner, Artifacts, Settings, Help)
- Reusable components in `client/src/components/`
- UI primitives in `client/src/components/ui/` (shadcn/ui)
- Custom hooks in `client/src/hooks/`
- Theme support (light/dark) via ThemeProvider context

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **Build**: esbuild for production bundling

The server follows a simple REST API pattern:
- Routes registered in `server/routes.ts`
- In-memory storage in `server/storage.ts` (implements IStorage interface)
- Static file serving for production in `server/static.ts`
- Vite dev server integration in `server/vite.ts`

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` with Zod validation via drizzle-zod
- **Current Storage**: In-memory MemStorage class (PostgreSQL ready via Drizzle config)

Key data entities:
- Users (authentication ready)
- RoverStatus (real-time rover state)
- GPRScan (scan data with GPS coordinates and data points)
- Artifact (discovered items with metadata and similarity scores)

### API Structure
REST endpoints under `/api/`:
- `GET /api/rover/status` - Current rover status
- `POST /api/rover/command` - Send control commands
- `GET /api/scans` - List all scans
- `POST /api/scans/start` - Start new scan
- `GET /api/artifacts` - List discovered artifacts

### Design System
- Fluent Design + Carbon Design hybrid approach
- 12-column grid layout with 3-panel dashboard structure
- Inter font for UI, JetBrains Mono for technical readouts
- CSS custom properties for comprehensive theming

## External Dependencies

### Core Libraries
- **@tanstack/react-query**: Server state management with polling support
- **drizzle-orm**: Type-safe database ORM
- **express**: HTTP server framework
- **zod**: Runtime type validation

### UI Framework
- **@radix-ui/react-***: Accessible UI primitives (dialog, dropdown, tabs, etc.)
- **class-variance-authority**: Component variant management
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library

### Database
- **PostgreSQL**: Configured via DATABASE_URL environment variable
- **drizzle-kit**: Database migration tooling

### Development
- **vite**: Frontend build and dev server
- **tsx**: TypeScript execution for development
- **esbuild**: Production server bundling