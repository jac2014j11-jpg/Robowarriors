import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationProvider, useNotifications } from "@/components/notification-provider";
import { NotificationBell } from "@/components/notification-bell";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Scanner from "@/pages/scanner";
import Artifacts from "@/pages/artifacts";
import SettingsPage from "@/pages/settings";
import Help from "@/pages/help";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/scanner" component={Scanner} />
      <Route path="/artifacts" component={Artifacts} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/help" component={Help} />
      <Route component={NotFound} />
    </Switch>
  );
}

function HeaderControls() {
  const { notifications, markAsRead, clearAll } = useNotifications();
  
  return (
    <div className="flex items-center gap-2">
      <NotificationBell
        notifications={notifications}
        onMarkAsRead={markAsRead}
        onClearAll={clearAll}
      />
      <ThemeToggle />
    </div>
  );
}

function AppContent() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <header className="flex h-14 items-center justify-between gap-4 border-b border-border px-4">
            <div className="flex items-center gap-3">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-foreground" data-testid="text-rover-name">
                  Smart Integrated Rover
                </span>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary" data-testid="badge-sir">
                  SIR
                </span>
              </div>
            </div>
            <HeaderControls />
          </header>
          <main className="flex-1 overflow-auto bg-background">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <NotificationProvider>
            <AppContent />
          </NotificationProvider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
