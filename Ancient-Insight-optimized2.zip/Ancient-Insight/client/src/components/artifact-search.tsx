import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Search, SlidersHorizontal, X } from "lucide-react";

interface ArtifactSearchProps {
  onSearch: (query: string) => void;
  onFilterChange: (filters: ArtifactFilters) => void;
  categories: string[];
  periods: string[];
}

export interface ArtifactFilters {
  category: string;
  period: string;
  minSimilarity: number;
}

export function ArtifactSearch({
  onSearch,
  onFilterChange,
  categories,
  periods,
}: ArtifactSearchProps) {
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState<ArtifactFilters>({
    category: "",
    period: "",
    minSimilarity: 0,
  });

  const handleSearch = (value: string) => {
    setQuery(value);
    onSearch(value);
  };

  const handleFilterChange = (key: keyof ArtifactFilters, value: string | number) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const clearFilters = () => {
    const emptyFilters = { category: "", period: "", minSimilarity: 0 };
    setFilters(emptyFilters);
    onFilterChange(emptyFilters);
  };

  const hasActiveFilters = filters.category || filters.period || filters.minSimilarity > 0;

  return (
    <div className="flex flex-col gap-4 sm:flex-row">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search artifacts by name, location, or description..."
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          className="h-12 pl-10"
          data-testid="input-artifact-search"
        />
      </div>

      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant={hasActiveFilters ? "default" : "outline"}
            className="h-12"
            data-testid="button-artifact-filters"
          >
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            Filters
            {hasActiveFilters && (
              <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary-foreground text-xs text-primary">
                {(filters.category ? 1 : 0) + (filters.period ? 1 : 0) + (filters.minSimilarity > 0 ? 1 : 0)}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="end">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Filters</h4>
              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  data-testid="button-clear-filters"
                >
                  <X className="mr-1 h-3 w-3" />
                  Clear
                </Button>
              )}
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={filters.category}
                onValueChange={(v) => handleFilterChange("category", v)}
              >
                <SelectTrigger data-testid="select-category">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Period</Label>
              <Select
                value={filters.period}
                onValueChange={(v) => handleFilterChange("period", v)}
              >
                <SelectTrigger data-testid="select-period">
                  <SelectValue placeholder="All periods" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All periods</SelectItem>
                  {periods.map((period) => (
                    <SelectItem key={period} value={period}>
                      {period}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Minimum Similarity</Label>
              <Select
                value={filters.minSimilarity.toString()}
                onValueChange={(v) => handleFilterChange("minSimilarity", parseFloat(v))}
              >
                <SelectTrigger data-testid="select-similarity">
                  <SelectValue placeholder="Any similarity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Any similarity</SelectItem>
                  <SelectItem value="0.5">50% or higher</SelectItem>
                  <SelectItem value="0.7">70% or higher</SelectItem>
                  <SelectItem value="0.9">90% or higher</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
