import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { RoverStatus } from "@shared/schema";

interface GPSDisplayProps {
  status: RoverStatus | undefined;
}

export function GPSDisplay({ status }: GPSDisplayProps) {
  const { toast } = useToast();

  const formatCoordinate = (value: number | undefined, type: 'lat' | 'lng') => {
    if (value === undefined) return "-.----°";
    const direction = type === 'lat' ? (value >= 0 ? 'N' : 'S') : (value >= 0 ? 'E' : 'W');
    return `${Math.abs(value).toFixed(6)}° ${direction}`;
  };

  const copyToClipboard = () => {
    if (status?.gpsLat && status?.gpsLng) {
      const coords = `${status.gpsLat.toFixed(6)}, ${status.gpsLng.toFixed(6)}`;
      navigator.clipboard.writeText(coords);
      toast({
        title: "Coordinates Copied",
        description: coords,
      });
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg font-medium">
          <MapPin className="h-5 w-5 text-primary" />
          GPS Coordinates
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              LAT
            </span>
            <span className="font-mono text-sm" data-testid="text-gps-lat">
              {formatCoordinate(status?.gpsLat, 'lat')}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              LNG
            </span>
            <span className="font-mono text-sm" data-testid="text-gps-lng">
              {formatCoordinate(status?.gpsLng, 'lng')}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              ELV
            </span>
            <span className="font-mono text-sm" data-testid="text-gps-elevation">
              {status?.gpsElevation?.toFixed(1) || "-.--"} m
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={copyToClipboard}
            disabled={!status?.gpsLat || !status?.gpsLng}
            data-testid="button-copy-coordinates"
          >
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
