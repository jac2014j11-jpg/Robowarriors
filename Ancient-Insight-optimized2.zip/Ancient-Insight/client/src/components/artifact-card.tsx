import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, MapPin, Calendar } from "lucide-react";
import type { Artifact } from "@shared/schema";

interface ArtifactCardProps {
  artifact: Artifact;
  onViewDetails?: (artifact: Artifact) => void;
}

export function ArtifactCard({ artifact, onViewDetails }: ArtifactCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-artifact-${artifact.id}`}>
      <div className="aspect-square bg-muted">
        {artifact.imageUrl ? (
          <img
            src={artifact.imageUrl}
            alt={artifact.name}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
            <span className="text-4xl text-muted-foreground/30">
              <MapPin className="h-16 w-16" />
            </span>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between gap-2">
          <h3 className="line-clamp-1 font-medium">{artifact.name}</h3>
          {artifact.similarity >= 0.8 && (
            <Badge className="shrink-0 bg-green-500/20 text-green-600 dark:text-green-400">
              High Match
            </Badge>
          )}
        </div>
        
        <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">
          {artifact.description}
        </p>
        
        <div className="mb-4 flex flex-wrap gap-2">
          <Badge variant="secondary" className="text-xs">
            {artifact.category}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {artifact.period}
          </Badge>
        </div>
        
        <div className="mb-4 space-y-1 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <MapPin className="h-3 w-3" />
            <span className="line-clamp-1">{artifact.location}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar className="h-3 w-3" />
            <span>{new Date(artifact.dateFound).toLocaleDateString()}</span>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onViewDetails?.(artifact)}
            data-testid={`button-view-artifact-${artifact.id}`}
          >
            View Details
          </Button>
          {artifact.externalLink && (
            <Button
              variant="ghost"
              size="icon"
              asChild
              data-testid={`button-external-link-${artifact.id}`}
            >
              <a href={artifact.externalLink} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
