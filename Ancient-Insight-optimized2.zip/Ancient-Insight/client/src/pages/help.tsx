import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  HelpCircle,
  BookOpen,
  MessageCircle,
  Video,
  FileText,
  ExternalLink,
  Search,
  Gauge,
  Scan,
  Database,
  Settings,
} from "lucide-react";
import { useState } from "react";

const faqItems = [
  {
    question: "How do I start a GPR scan?",
    answer:
      "Navigate to the Dashboard or Scanner page and click the 'Start Scan' button. Make sure manual override is enabled for real-time control. The rover will begin collecting ground-penetrating radar data immediately.",
  },
  {
    question: "What do the different status indicators mean?",
    answer:
      "Green indicates active/connected, yellow indicates standby or charging, and red indicates an error or disconnection. The pulsing animation shows real-time data transmission.",
  },
  {
    question: "How does the solar panel management work?",
    answer:
      "The rover automatically manages solar charging based on battery levels and current operations. You can toggle the solar panel on/off manually via the control panel, or set it to automatic mode in Settings.",
  },
  {
    question: "What is LoRaWAN and when should I use it?",
    answer:
      "LoRaWAN (Long Range Wide Area Network) is used for low-power, long-range communication. Use it when the rover is within range of your local network. For remote locations, use Starlink satellite connection.",
  },
  {
    question: "How do I interpret GPR data?",
    answer:
      "GPR data is displayed as a cross-section view showing subsurface features. Bright areas indicate strong reflections (potential artifacts), while the depth slider lets you explore different layers. Use the 2D/3D toggle for different visualization modes.",
  },
  {
    question: "How accurate is the artifact detection?",
    answer:
      "The AI-powered artifact detection has approximately 85% accuracy. High confidence scores (>70%) indicate strong matches with known artifact signatures. Always verify potential findings with manual inspection.",
  },
  {
    question: "Can I export scan data?",
    answer:
      "Yes, scan data can be exported in JSON, CSV, or GeoJSON formats. Use the export button on individual scans or bulk export from the Settings page. Data includes GPS coordinates, depth readings, and detection confidence scores.",
  },
  {
    question: "What should I do if connection is lost?",
    answer:
      "The rover will automatically attempt to reconnect. If manual intervention is needed, check the communication settings and ensure either LoRaWAN or Starlink is enabled. The rover will continue scanning and store data locally until connection is restored.",
  },
];

const quickGuides = [
  {
    title: "Dashboard Overview",
    icon: Gauge,
    description: "Monitor rover status, battery, and active scans",
  },
  {
    title: "GPR Scanning",
    icon: Scan,
    description: "Configure and control ground-penetrating radar",
  },
  {
    title: "Artifact Database",
    icon: Database,
    description: "Search and compare similar artifacts",
  },
  {
    title: "System Settings",
    icon: Settings,
    description: "Configure communication and power settings",
  },
];

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredFAQ = faqItems.filter(
    (item) =>
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold">Help & Documentation</h1>
        <p className="text-sm text-muted-foreground">
          Learn how to use the ArchaeoRover control system effectively
        </p>
      </div>

      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search help articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
          data-testid="input-help-search"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {quickGuides.map((guide) => (
          <Card key={guide.title} className="hover-elevate cursor-pointer">
            <CardContent className="flex items-start gap-4 p-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <guide.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">{guide.title}</h3>
                <p className="text-sm text-muted-foreground">{guide.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-medium">
            <HelpCircle className="h-5 w-5 text-primary" />
            Frequently Asked Questions
          </CardTitle>
          <CardDescription>
            Find answers to common questions about the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredFAQ.length === 0 ? (
            <div className="py-8 text-center">
              <HelpCircle className="mx-auto mb-4 h-12 w-12 text-muted-foreground/30" />
              <p className="text-muted-foreground">
                No results found for "{searchQuery}"
              </p>
            </div>
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {filteredFAQ.map((item, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left" data-testid={`faq-question-${index}`}>
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="flex flex-col items-center p-6 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-500/10">
              <BookOpen className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="mb-2 font-medium">Documentation</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              Detailed technical documentation and API reference
            </p>
            <Button variant="outline" className="w-full" data-testid="button-docs">
              <FileText className="mr-2 h-4 w-4" />
              View Docs
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col items-center p-6 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-500/10">
              <Video className="h-6 w-6 text-green-500" />
            </div>
            <h3 className="mb-2 font-medium">Video Tutorials</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              Step-by-step video guides for common tasks
            </p>
            <Button variant="outline" className="w-full" data-testid="button-tutorials">
              <ExternalLink className="mr-2 h-4 w-4" />
              Watch Tutorials
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col items-center p-6 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-purple-500/10">
              <MessageCircle className="h-6 w-6 text-purple-500" />
            </div>
            <h3 className="mb-2 font-medium">Contact Support</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              Get help from our technical support team
            </p>
            <Button variant="outline" className="w-full" data-testid="button-contact">
              <MessageCircle className="mr-2 h-4 w-4" />
              Contact Us
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="flex items-center justify-between gap-4 p-4">
          <div className="flex items-center gap-3">
            <Badge variant="secondary">v2.4.1</Badge>
            <span className="text-sm text-muted-foreground">
              ArchaeoRover Control System
            </span>
          </div>
          <Button variant="ghost" size="sm" data-testid="button-release-notes">
            Release Notes
            <ExternalLink className="ml-2 h-3 w-3" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
