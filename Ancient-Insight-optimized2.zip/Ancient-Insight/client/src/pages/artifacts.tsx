import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArtifactCard } from "@/components/artifact-card";
import { ArtifactDetailModal } from "@/components/artifact-detail-modal";
import { ArtifactSearch, type ArtifactFilters } from "@/components/artifact-search";
import { Skeleton } from "@/components/ui/skeleton";
import { Database } from "lucide-react";
import type { Artifact } from "@shared/schema";

export default function Artifacts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<ArtifactFilters>({
    category: "",
    period: "",
    minSimilarity: 0,
  });
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);

  const { data: artifacts = [], isLoading } = useQuery<Artifact[]>({
    queryKey: ["/api/artifacts"],
  });

  const categories = useMemo(() => {
    const cats = new Set(artifacts.map((a) => a.category));
    return Array.from(cats).sort();
  }, [artifacts]);

  const periods = useMemo(() => {
    const pers = new Set(artifacts.map((a) => a.period));
    return Array.from(pers).sort();
  }, [artifacts]);

  const filteredArtifacts = useMemo(() => {
    return artifacts.filter((artifact) => {
      const matchesQuery =
        !searchQuery ||
        artifact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artifact.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artifact.location.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        !filters.category || filters.category === "all" || artifact.category === filters.category;

      const matchesPeriod =
        !filters.period || filters.period === "all" || artifact.period === filters.period;

      const matchesSimilarity = artifact.similarity >= filters.minSimilarity;

      return matchesQuery && matchesCategory && matchesPeriod && matchesSimilarity;
    });
  }, [artifacts, searchQuery, filters]);

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold">Artifact Database</h1>
        <p className="text-sm text-muted-foreground">
          Search and browse similar artifacts found in archaeological surveys
        </p>
      </div>

      <ArtifactSearch
        onSearch={setSearchQuery}
        onFilterChange={setFilters}
        categories={categories}
        periods={periods}
      />

      {isLoading ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="space-y-3">
              <Skeleton className="aspect-square" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
          ))}
        </div>
      ) : filteredArtifacts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Database className="mb-4 h-16 w-16 text-muted-foreground/30" />
          <h3 className="text-lg font-medium">No artifacts found</h3>
          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            {searchQuery || filters.category || filters.period || filters.minSimilarity > 0
              ? "Try adjusting your search filters to find more results"
              : "Start scanning to discover artifacts and find similar records"}
          </p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {filteredArtifacts.length} of {artifacts.length} artifacts
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredArtifacts.map((artifact) => (
              <ArtifactCard
                key={artifact.id}
                artifact={artifact}
                onViewDetails={setSelectedArtifact}
              />
            ))}
          </div>
        </>
      )}

      <ArtifactDetailModal
        artifact={selectedArtifact}
        open={!!selectedArtifact}
        onOpenChange={(open) => !open && setSelectedArtifact(null)}
      />
    </div>
  );
}
